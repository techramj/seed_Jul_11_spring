package com.easylearning.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ImportResource;

import com.easylearning.model.Address;
import com.easylearning.model.Employee;

@ImportResource(value = "classpath:spring.xml")
public class JavaConfig2 {
	
	@Bean
	public Employee emp(Address address) {
		Employee e= new Employee();
		e.setId(10);
		e.setName("Jack");
		e.setSalary(4000);
		e.setAddress(address);
		return e;
	}
}
