package com.easylearning.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.easylearning.config.JavaConfig2;
import com.easylearning.model.Address;
import com.easylearning.model.Employee;

public class Main {

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(JavaConfig2.class);
		Address address = context.getBean("address", Address.class);
		System.out.println(address);

		Employee emp = context.getBean("emp", Employee.class);
		System.out.println(emp);
	}

}
