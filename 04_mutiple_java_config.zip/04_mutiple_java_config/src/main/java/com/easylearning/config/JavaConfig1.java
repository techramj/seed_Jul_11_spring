package com.easylearning.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.easylearning.model.Address;

@Configuration
public class JavaConfig1 {
	
	@Bean
	public Address address() {
		Address address = new Address();
		address.setCity("Mumbai");
		return address;
	}

}
