package com.easylearning.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.easylearning.model.Bike;
import com.easylearning.model.Car;

public class Main {
	
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		
		//Bike bike1 = context.getBean("bike", Bike.class);
		
		//Bike bike2 = context.getBean("bike", Bike.class);
		((ConfigurableApplicationContext)context).close();
		
		
		System.out.println("end!!!!!!!!!!!!!!!!!");
		
	}

}
