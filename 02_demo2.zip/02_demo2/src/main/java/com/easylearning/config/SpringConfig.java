package com.easylearning.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.easylearning.model.Address;
import com.easylearning.model.Employee;

@Configuration
public class SpringConfig {
	
	@Bean
	public Address address() {
		Address address = new Address();
		address.setCity("Mumbai");
		return address;
	}
	
	@Bean
	public Employee emp() {
		Employee e= new Employee();
		e.setId(10);
		e.setName("Jack");
		e.setSalary(4000);
		e.setaAddress(address());
		return e;
	}

}
