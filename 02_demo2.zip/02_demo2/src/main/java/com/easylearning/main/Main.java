package com.easylearning.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.easylearning.config.SpringConfig;
import com.easylearning.model.Address;
import com.easylearning.model.Employee;

public class Main {

	public static void sample1() {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");

		Employee employee = (Employee) context.getBean("employee");
		System.out.println(employee);
	}

	public static void sample2() {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");

		Employee employee = context.getBean("employee", Employee.class);
		System.out.println(employee);
	}

	public static void sample3() {
		ApplicationContext context = 
				new AnnotationConfigApplicationContext(SpringConfig.class);
		Address address = context.getBean("address", Address.class);
		System.out.println(address);
		
		Employee emp =  context.getBean("emp", Employee.class);
		System.out.println(emp);
	}

	public static void main(String[] args) {
		sample3();
	}

}
