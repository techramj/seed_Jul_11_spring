package com.easylearning.service;

import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.easylearning.entity.Project;

@Service
public class ProjectService {
	
	private List<Project> projects = new LinkedList<>();
	
	public ProjectService() {
		projects.add(createProject("Core Java Project", "Seed Infotech"));
		projects.add(createProject("Hibernate Project", "Seed Infotech"));
		projects.add(createProject("Spring boot Project", "Easy Learning"));
		projects.add(createProject("SQL/PLSQL/Angular Project", "Easy Learning"));
	}
	
	public List<Project> findAll(){
		return projects;
	}
	
	public Project findById(Long id) {
		return projects.stream().filter(p->p.getProjectId().equals(id)).findAny().get();
	}
	
	
	static long id=0;
	private Project createProject(String name, String sponsor) {
		Project project = new Project();
		project.setProjectId(++id);
		project.setName(name);
		project.setSponsor(sponsor);
		
		return project;
	}

}
