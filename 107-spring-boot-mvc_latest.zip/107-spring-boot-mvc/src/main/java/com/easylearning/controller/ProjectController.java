package com.easylearning.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.easylearning.service.ProjectService;

@RequestMapping("project")
@Controller
public class ProjectController {
	
	@Autowired
	private ProjectService projectService;
	
	@RequestMapping(value = "/add", method=RequestMethod.GET)
	public String addProject() {
		System.out.println("get method");
		return "project_add";
	}
	
	@RequestMapping(value = "/add", method=RequestMethod.POST)
	public String saveProject() {
		System.out.println("post method");
		return "project_add";
	}
	
	
	@RequestMapping("/find")
	public String findAllProject(Model model) {
		model.addAttribute("projects", projectService.findAll());
		return "projects";
	}
	
	
	@RequestMapping("/find/{id}")
	public String findAllProject(Model model, @PathVariable("id") Long id) {
		System.out.println("id="+id);
		model.addAttribute("project", projectService.findById(id));
		return "project";
	}
	
	

}
