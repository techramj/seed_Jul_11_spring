package com.easylearning.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MainController {
	
	@RequestMapping(value = "test")
	@ResponseBody
	public String test() {
		return "test";
	}
	
	@RequestMapping(value={"sample", "/" , "home"})
	public String samplePage() {
		return "sample";
	}

}
