package com.easylearning.model;

import org.springframework.stereotype.Component;

@Component
public class Address {

	private String name;

	public Address() {
		// TODO Auto-generated constructor stub
	}

	public Address(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
