package com.easylearning;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.easylearning.model.Address;

//@SpringBootApplication
@Configuration
@ComponentScan(value = {"com.easylearning"})
public class Application {
	
	private static Logger logger =LoggerFactory.getLogger(Application.class);

	public static void main(String[] args) {
		//ApplicationContext context= new ClassPathXmlApplicationContext("spring.xml");
		ApplicationContext context = new AnnotationConfigApplicationContext(Application.class);
		Address address = context.getBean("address", Address.class);
		logger.info("address ={}", address);
	}

}








