package com.easylearning.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@RequestMapping("project")
@Controller
public class ProjectController {
	
	
	@RequestMapping(value = "/add", method=RequestMethod.GET)
	public String addProject() {
		System.out.println("get method");
		return "project_add";
	}
	
	@RequestMapping(value = "/save", method=RequestMethod.POST)
	public String saveProject() {
		System.out.println("get method");
		return "project_add";
	}

}
