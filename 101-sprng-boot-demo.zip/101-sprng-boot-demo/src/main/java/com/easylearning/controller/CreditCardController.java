package com.easylearning.controller;

import java.sql.Time;
import java.time.Instant;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.easylearning.model.CreditCard;

@RestController
public class CreditCardController {
	
	private static Logger logger = LoggerFactory.getLogger(CreditCardController.class);
	
	@GetMapping("/test")
	public String test() {
		logger.debug("In debug mode:  test method called");
		return "another small test";
	}
	
	@GetMapping("/credit-card")
	public CreditCard getCreditCard() {
		logger.info("In debug mode:  getCreditCard method called");
		return new CreditCard("123412341234",124,null);
	}

}
