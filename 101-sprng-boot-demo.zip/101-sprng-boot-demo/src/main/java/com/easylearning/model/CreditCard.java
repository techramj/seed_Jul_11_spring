package com.easylearning.model;

import java.util.Date;

import org.springframework.stereotype.Component;

@Component
public class CreditCard {
	private String creditCardNo;
	private int ccv;
	private Date expiryDate;

	public CreditCard() {
		// TODO Auto-generated constructor stub
	}

	public CreditCard(String creditCardNo, int ccv, Date expiryDate) {
		super();
		this.creditCardNo = creditCardNo;
		this.ccv = ccv;
		this.expiryDate = expiryDate;
	}

	public String getCreditCardNo() {
		return creditCardNo;
	}

	public void setCreditCardNo(String creditCardNo) {
		this.creditCardNo = creditCardNo;
	}

	public int getCcv() {
		return ccv;
	}

	public void setCcv(int ccv) {
		this.ccv = ccv;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	@Override
	public String toString() {
		return "CreditCard [creditCardNo=" + creditCardNo + ", ccv=" + ccv + ", expiryDate=" + expiryDate + "]";
	}

}
