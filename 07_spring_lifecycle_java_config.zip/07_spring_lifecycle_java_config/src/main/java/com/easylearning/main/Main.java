package com.easylearning.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.easylearning.model.Bike;

public class Main {
	
	public static void main(String[] args) {
		System.out.println("start");
		ApplicationContext context = new AnnotationConfigApplicationContext(JavaConfig.class);
		Bike bike = context.getBean("bike",Bike.class);
		System.out.println(bike);
		((ConfigurableApplicationContext)context).close();
		
	}

}
