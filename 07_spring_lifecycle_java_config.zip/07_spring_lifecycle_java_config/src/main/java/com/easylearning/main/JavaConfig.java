package com.easylearning.main;

import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.easylearning.model.Bike;

@Configuration
public class JavaConfig {

	
	@Bean(initMethod = "init", destroyMethod = "destroy")
	public Bike bike() {
		return new Bike("Honda");
	}
	
	@Bean
	public BeanPostProcessor bpp() {
		return new MyBeanProcessor();
	}
}
