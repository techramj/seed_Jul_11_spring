package com.easylearning.model;

public class Bike {
	
	private String name;
	
	public Bike() {
		System.out.println("Bike: Default constructor");
	}

	public Bike(String name) {
		System.out.println("Bike: Paramterized constructor");
		this.name = name;
	}

	public String getName() {
		System.out.println("Bike: getter method -> getName");
		return name;
	}

	public void setName(String name) {
		System.out.println("Bike: setter method -> getName");
		this.name = name;
	}
	
	public void init() {
		System.out.println("Bike: init method");
	}
	
	public void destroy() {
		System.out.println("Bike: destroy method");
	}

}
