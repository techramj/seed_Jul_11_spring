package com.easylearning.dao;

import java.util.List;

import com.easylearning.entity.CreditCard;

public interface CreditCardDao {

	public CreditCard getCreditCard(Long id);

	public void deleteCreditCard(Long id);

	public CreditCard updateCreditCard(CreditCard card) ;

	public void addCreditCard(CreditCard card) ;

	public List<CreditCard> getAllCreditCard();


}
