package com.easylearning.model;

import java.util.Date;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class CreditCard {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	private Long id;
	private String creditCardNo;
	private int ccv;
	private Date expiryDate;

	public CreditCard() {
		// TODO Auto-generated constructor stub
	}

	public CreditCard(String creditCardNo, int ccv, Date expiryDate) {
		super();
		this.creditCardNo = creditCardNo;
		this.ccv = ccv;
		this.expiryDate = expiryDate;
	}

	public String getCreditCardNo() {
		return creditCardNo;
	}

	public void setCreditCardNo(String creditCardNo) {
		this.creditCardNo = creditCardNo;
	}

	public int getCcv() {
		return ccv;
	}

	public void setCcv(int ccv) {
		this.ccv = ccv;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	@Override
	public String toString() {
		return "CreditCard [creditCardNo=" + creditCardNo + ", ccv=" + ccv + ", expiryDate=" + expiryDate + "]";
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@PostConstruct
	public void init() {
		logger.info("init method called");
	}

	@PreDestroy
	public void destroy() {
		logger.info("destoy method called");
	}

}
