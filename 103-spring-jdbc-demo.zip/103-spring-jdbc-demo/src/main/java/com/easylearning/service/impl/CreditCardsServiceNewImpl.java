package com.easylearning.service.impl;

import java.util.List;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.easylearning.model.CreditCard;
import com.easylearning.service.CreditCardService;

@Primary
@Service
public class CreditCardsServiceNewImpl  implements CreditCardService{

	@Override
	public void validateCard(String cardNo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public CreditCard getCreditCardDetail(String creditCardNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<CreditCard> getCreditCards() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CreditCard save(CreditCard card) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String delete(String creditCardNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CreditCard update(CreditCard card) {
		// TODO Auto-generated method stub
		return null;
	}

}
