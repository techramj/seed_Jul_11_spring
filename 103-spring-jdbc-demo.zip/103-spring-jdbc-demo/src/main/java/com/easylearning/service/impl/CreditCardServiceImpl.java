package com.easylearning.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.easylearning.dao.CreditCardDao;
import com.easylearning.model.CreditCard;
import com.easylearning.service.CreditCardService;

@Component
public class CreditCardServiceImpl implements CreditCardService {

	@Autowired
	private CreditCardDao creditCardDao;

	
	@Override
	public void validateCard(String cardNo) {
		// 1234 4567 7868 1111
		// validate the card no
		// not valid throw the expection
		if (creditCardDao.getCreditCard(cardNo) == null) {
			// throw exception
		}

	}

	@Override
	public CreditCard getCreditCardDetail(String creditCardNo) {
		return creditCardDao.getCreditCard(creditCardNo);
	}

	@Override
	public List<CreditCard> getCreditCards() {
		return creditCardDao.getAllCreditCard();
	}

	@Override
	public CreditCard save(CreditCard card) {
		creditCardDao.addCreditCard(card);
		return card;
	}

	@Override
	public String delete(String creditCardNo) {
		creditCardDao.deleteCreditCard(creditCardNo);
		return "Card delete successfully";
	}

	@Override
	public CreditCard update(CreditCard card) {
		validateCard(card.getCreditCardNo());
		return creditCardDao.updateCreditCard(card);
	}

}
