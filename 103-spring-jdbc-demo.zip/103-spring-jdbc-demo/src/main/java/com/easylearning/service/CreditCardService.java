package com.easylearning.service;

import java.util.List;

import com.easylearning.model.CreditCard;


public interface CreditCardService {
	
	public void validateCard(String cardNo);
	
	public CreditCard getCreditCardDetail(String creditCardNo) ;
	
	public List<CreditCard> getCreditCards();
	
	public CreditCard save(CreditCard card) ;
	
	public String delete(String creditCardNo);
	
	public CreditCard update(CreditCard card) ;
}
