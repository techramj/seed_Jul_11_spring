package com.easylearning.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.time.Instant;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.easylearning.model.CreditCard;
import com.easylearning.service.CreditCardService;

@RestController
public class CreditCardController {

	private static Logger logger = LoggerFactory.getLogger(CreditCardController.class);

	@Autowired
	private CreditCardService creditCardService;

	@GetMapping("/test")
	public String test() {
		logger.debug("In debug mode:  test method called");
		return "another small test";
	}

	@GetMapping("/credit-card/{creditCardNo}")
	public CreditCard getCreditCard(@PathVariable("creditCardNo") String creditcardNo) {
		logger.info("In debug mode:  getCreditCard no: " + creditcardNo);
		
		//validate card 
		creditCardService.validateCard(creditcardNo);
		
		return creditCardService.getCreditCardDetail(creditcardNo);
	}

	@GetMapping("/credit-card")
	public List<CreditCard> getCreditCards() {
		return creditCardService.getCreditCards();
	}
	
	@PostMapping("/credit-card")
	public CreditCard addCreditCard(@RequestBody CreditCard card) {
		logger.info("card="+card);
		return creditCardService.save(card);
	}
	
	
	@DeleteMapping("/credit-card/{creditCardNo}")
	public String delete(@PathVariable("creditCardNo") String creditcardNo) {
		return creditCardService.delete(creditcardNo);
	}
	
	
	@PutMapping("/credit-card")
	public CreditCard updateCreditCard(@RequestBody CreditCard card) {
		logger.info("card="+card);
		return creditCardService.update(card);
	}

	

}
