package com.easylearning.dao;

import java.util.List;

import com.easylearning.model.CreditCard;

public interface CreditCardDao {

	public CreditCard getCreditCard(String cardNo);

	public void deleteCreditCard(String cardNo);

	public CreditCard updateCreditCard(CreditCard card) ;

	public void addCreditCard(CreditCard card) ;

	public List<CreditCard> getAllCreditCard();


}
