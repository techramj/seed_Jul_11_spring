package com.easylearning.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Component;

import com.easylearning.model.CreditCard;

@Component
public class CreditCardDaoDummyImpl implements CreditCardDao {

	/*
	 * @Autowired private Connection connection;
	 */

	@Override
	public CreditCard getCreditCard(String cardNo) {

		/*
		 * for (CreditCard card : creditCardList) { if
		 * (card.getCreditCardNo().equals(cardNo)) { return card; } } return null;
		 */
		return creditCardList.stream().filter(c -> c.getClass().equals(cardNo)).findFirst().orElse(null);
	}

	@Override
	public void deleteCreditCard(String cardNo) {
		Iterator<CreditCard> itr = creditCardList.iterator();
		while (itr.hasNext()) {
			if (itr.next().getCreditCardNo().equals(cardNo)) {
				itr.remove();
			}
		}
	}

	@Override
	public CreditCard updateCreditCard(CreditCard card) {
		for (CreditCard c : creditCardList) {
			if (c.getCreditCardNo().equals(card.getCreditCardNo())) {
				c.setCcv(card.getCcv());
				c.setExpiryDate(card.getExpiryDate());
				return c;
			}
		}
		return null;
	}

	@Override
	public void addCreditCard(CreditCard card) {
		creditCardList.add(card);
	}

	@Override
	public List<CreditCard> getAllCreditCard() {

		/*
		 * String sql = "select ccv, expiry_date from creditCards where id=?"; try
		 * (PreparedStatement ps = connection.prepareStatement(sql)) { ps.setString(1,
		 * creditcardNo); try (ResultSet rs = ps.executeQuery();) { if (rs.next()) {
		 * CreditCard card = new CreditCard(); card.setCcv(rs.getInt(1));
		 * card.setExpiryDate(rs.getDate(2)); card.setCreditCardNo(creditcardNo); return
		 * card; } else { // throw not valid credit card } } } catch (SQLException e) {
		 * 
		 * }
		 */
		return creditCardList;
	}

	private static List<CreditCard> creditCardList = new ArrayList<CreditCard>();
	static {

		creditCardList = new ArrayList<CreditCard>(
				Arrays.asList(new CreditCard("1", 123, new Date()), new CreditCard("1111", 123, new Date()),
						new CreditCard("5", 124, new Date()), new CreditCard("8", 128, new Date()),
						new CreditCard("11", 143, new Date()), new CreditCard("10", 123, new Date())));

	}

}
