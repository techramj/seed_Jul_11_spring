package com.easylearning;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.easylearning.dao.CreditCardJpaRepository;
import com.easylearning.model.CreditCard;

@SpringBootApplication
public class Application implements CommandLineRunner{
	
	@Autowired
	private CreditCardJpaRepository dao;

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		//fetch all the creditcard
		dao.findAll().forEach(System.out::println);
		
		System.out.println("------------------");
		Optional<CreditCard> findById = dao.findById(1002L);
		System.out.println(findById.get());
		
	}
	
	


}
