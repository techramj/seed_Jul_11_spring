package com.easylearning.service;

import java.util.List;

import com.easylearning.model.CreditCard;


public interface CreditCardService {
	
	public void validateCard(Long id);
	
	public CreditCard getCreditCardDetail(Long id) ;
	
	public List<CreditCard> getCreditCards();
	
	public CreditCard save(CreditCard card) ;
	
	public String delete(Long creditCardNo);
	
	public CreditCard update(CreditCard card) ;
}
