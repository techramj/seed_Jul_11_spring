package com.easylearning.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@NamedQuery(name="find_all_credit_card", query = "select c from CreditCard c")
@Entity
public class CreditCard {
	
	@Id
	@GeneratedValue
	private Long id;
	
	//@Column(name = "credit_card_no")
	private String creditCardNo;
	
	private int ccv;
	
	private Date expiryDate;
	//private static Long idGenerator = 0L;

	public CreditCard() {
		//id = ++idGenerator;
	}

	public CreditCard(String creditCardNo, int ccv, Date expiryDate) {
		//id = ++idGenerator;
		this.creditCardNo = creditCardNo;
		this.ccv = ccv;
		this.expiryDate = expiryDate;
	}

	public String getCreditCardNo() {
		return creditCardNo;
	}

	public void setCreditCardNo(String creditCardNo) {
		this.creditCardNo = creditCardNo;
	}

	public int getCcv() {
		return ccv;
	}

	public void setCcv(int ccv) {
		this.ccv = ccv;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	

	@Override
	public String toString() {
		return "CreditCard [id=" + id + ", creditCardNo=" + creditCardNo + ", ccv=" + ccv + ", expiryDate=" + expiryDate
				+ "]";
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}


}
