package com.easylearning.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.easylearning.model.CreditCard;
import com.easylearning.service.CreditCardService;

@RestController
public class CreditCardController {

	private static Logger logger = LoggerFactory.getLogger(CreditCardController.class);

	@Autowired
	private CreditCardService creditCardService;

	@GetMapping("/test")
	public String test() {
		logger.debug("In debug mode:  test method called");
		return "another small test";
	}

	@GetMapping("/credit-card/{id}")
	public CreditCard getCreditCard(@PathVariable("id") Long id) {
		
		creditCardService.validateCard(id);
		
		return creditCardService.getCreditCardDetail(id);
	}

	@GetMapping("/credit-card")
	public List<CreditCard> getCreditCards() {
		return creditCardService.getCreditCards();
	}
	
	@PostMapping("/credit-card")
	public CreditCard addCreditCard(@RequestBody CreditCard card) {
		logger.info("card="+card);
		return creditCardService.save(card);
	}
	
	
	@DeleteMapping("/credit-card/{id}")
	public String delete(@PathVariable("id") Long id) {
		return creditCardService.delete(id);
	}
	
	
	@PutMapping("/credit-card")
	public CreditCard updateCreditCard(@RequestBody CreditCard card) {
		logger.info("card="+card);
		return creditCardService.update(card);
	}

	

}
