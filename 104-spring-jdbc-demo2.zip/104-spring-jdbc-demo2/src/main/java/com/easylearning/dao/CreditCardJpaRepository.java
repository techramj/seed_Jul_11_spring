package com.easylearning.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.easylearning.model.CreditCard;

public interface CreditCardJpaRepository extends JpaRepository<CreditCard, Long> {

}
