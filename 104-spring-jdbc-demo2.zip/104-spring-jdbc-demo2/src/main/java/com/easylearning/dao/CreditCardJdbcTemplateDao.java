package com.easylearning.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.easylearning.model.CreditCard;

//@Primary
@Repository
public class CreditCardJdbcTemplateDao implements CreditCardDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public CreditCard getCreditCard(Long id) {
		String sql = "select * from credit_card where id=?";
		CreditCard card = jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<CreditCard>(CreditCard.class),
				new Object[] { id });

		return card;
	}

	@Override
	public void deleteCreditCard(Long id) {
		String sql = "delete from credit_card where id=?";
		int update = jdbcTemplate.update(sql, new Object[] { id });
	}

	@Override
	public CreditCard updateCreditCard(CreditCard card) {
		String sql = "update credit_card set ccv=?, expiry_date=? where id=?";
		int update = jdbcTemplate.update(sql, new Object[] { card.getCcv(), card.getExpiryDate(), card.getId() });
		return card;
	}

	@Override
	public void addCreditCard(CreditCard card) {
		String sql = "insert into credit_card(id, credit_card_no, ccv, expiry_date) values (?,?,?,?)";
		int update = jdbcTemplate.update(sql,
				new Object[] { card.getId(), card.getCreditCardNo(), card.getCcv(), card.getExpiryDate() });

	}

	@Override
	public List<CreditCard> getAllCreditCard() {
		String sql = "select * from credit_card";
		// List<CreditCard> list = jdbcTemplate.query(sql, new
		// BeanPropertyRowMapper<CreditCard>(CreditCard.class));
		List<CreditCard> list = jdbcTemplate.query(sql, new CreditCardRowMapper());
		return list;
	}

	class CreditCardRowMapper implements RowMapper<CreditCard> {

		@Override
		public CreditCard mapRow(ResultSet rs, int rowNum) throws SQLException {
			CreditCard card = new CreditCard();
			card.setId(rs.getLong(1));
			card.setCreditCardNo(rs.getString(2));
			card.setCcv(rs.getInt(3));
			card.setExpiryDate(rs.getDate(4));
			return card;
		}

	}

}
