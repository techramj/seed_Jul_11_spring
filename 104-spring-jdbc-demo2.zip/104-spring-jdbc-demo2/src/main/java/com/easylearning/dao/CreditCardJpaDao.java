package com.easylearning.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

import com.easylearning.model.CreditCard;


@Primary
@Transactional
@Repository
public class CreditCardJpaDao implements CreditCardDao{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public CreditCard getCreditCard(Long id) {
		return entityManager.find(CreditCard.class, id);
	}

	@Override
	public void deleteCreditCard(Long id) {
		CreditCard card = getCreditCard(id);
		entityManager.remove(card);
	}

	@Override
	public CreditCard updateCreditCard(CreditCard card) {
		return entityManager.merge(card);
	}

	@Override
	public void addCreditCard(CreditCard card) {
		entityManager.merge(card);
		
	}

	@Override
	public List<CreditCard> getAllCreditCard() {
		TypedQuery<CreditCard> query = entityManager.createNamedQuery("find_all_credit_card", CreditCard.class);
		return query.getResultList();
	}

}
