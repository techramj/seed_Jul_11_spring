/*
create table credit_card(
   id integer,
   credit_card_no varchar2(30),
   ccv  integer,
   expiry_date timestamp
);
*/




