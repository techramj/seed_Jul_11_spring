insert into credit_card(id, credit_card_no, ccv, expiry_date) values (1001,'111122223333',123, current_date()+100);
insert into credit_card(id, credit_card_no, ccv, expiry_date) values (1002,'111122223344',333, current_date()+200);
insert into credit_card(id, credit_card_no, ccv, expiry_date) values (1003,'11112222333',444, current_date()+300);
insert into credit_card(id, credit_card_no, ccv, expiry_date) values (1004,'111122223355',123, current_date()+400);
