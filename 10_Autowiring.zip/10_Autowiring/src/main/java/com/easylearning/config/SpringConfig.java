package com.easylearning.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.easylearning.model.Address;
import com.easylearning.model.Employee;

@ComponentScan(value = {"com.easylearning"})
@Configuration
public class SpringConfig {
	


}
