package com.easylearning.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.easylearning.model.A;
import com.easylearning.model.B;
import com.easylearning.model.Bike;
import com.easylearning.model.Car;

public class Main {
	
	public static void main(String[] args) {
		
		//A a = new A(null);
		//B b = new B(a);
		//a.setB(b);
		
		//ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		ApplicationContext context = new AnnotationConfigApplicationContext(JavaConfig.class);
		A a = context.getBean("a",A.class);
		B b = context.getBean("b", B.class);
		System.out.println(a +"   "+a.getB());
		System.out.println(b+"  "+b.getA());
		
		
	}

}
