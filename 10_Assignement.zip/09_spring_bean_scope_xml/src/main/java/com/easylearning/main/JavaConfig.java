package com.easylearning.main;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.easylearning.model.A;
import com.easylearning.model.B;

@Configuration
public class JavaConfig {
	
	@Bean
	public A a() {
		A a= new A(null);
		return a;
	}
	
	/*@Bean
	public B b(A a) {
		B b=new B(a);
		a.setB(b);
		return b ;
	}*/
	
	
	@Bean
	public B b() {
		A a= a();
		B b=new B(a);
		a.setB(b);
		return b ;
	}
}
