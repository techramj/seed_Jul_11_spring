package com.easylearning.model;

public class B {
	
	private A a;
	
	public B(A a) {
		this.a=a;
	}

	public A getA() {
		return a;
	}

	public void setA(A a) {
		this.a = a;
	}
}
