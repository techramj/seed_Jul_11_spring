package com.easylearning.model;

public class Vehicle {

}
