package com.easylearning.main;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import com.easylearning.config.SpringConfig;
import com.easylearning.model.Address;
import com.easylearning.model.Employee;

public class Main {

	public static void xmlDemo() {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Address address = context.getBean("address", Address.class);
		System.out.println(address);
		
		Employee emp = context.getBean("employee", Employee.class);
		System.out.println(emp+"   "+emp.getAddress());
	}
	
	public static void javaConfigDemo() {
		ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
		Address address = context.getBean("address", Address.class);
		System.out.println(address);
		
		Employee emp = context.getBean("employee", Employee.class);
		System.out.println(emp+"   Address:"+emp.getAddress());
	}
	
	
	public static void xmlAutowireDemo() {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		
		Employee emp = context.getBean("employee", Employee.class);
		System.out.println(emp);
		System.out.println("Address: "+emp.getAddress());
		System.out.println("Vehicle: "+emp.getVehicle());
	}

	public static void main(String[] args) {
		xmlAutowireDemo();
	}

}
