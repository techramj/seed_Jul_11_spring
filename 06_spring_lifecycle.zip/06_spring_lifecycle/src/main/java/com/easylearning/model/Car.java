package com.easylearning.model;

public class Car {

	private String color;
	private String name;

	public Car() {
		System.out.println("Car: Default constructor");
	}

	public Car(String color, String name) {
		System.out.println("Car: Parameterized constructor");
		this.color = color;
		this.name = name;
	}
	
	public Car(String color) {
		this.color = color;
	}
	
	
	
	
	
	

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		System.out.println("Car: setter -> setColor");
		this.color = color;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		System.out.println("Car: setter -> setName");
		this.name = name;
	}

	@Override
	public String toString() {
		return "Car [color=" + color + ", name=" + name + "]";
	}
	
	public void init() {
		System.out.println("Car: init method");
	}
	
	public void destroy() {
		System.out.println("Car: destroy method");
	}

}
