package com.easylearning.model;

public class SampleBean {
	
	private int id;
	private String name;
	
	
	public SampleBean() {
		// TODO Auto-generated constructor stub
	}
	
	public SampleBean(int id) {
		this.id = id;
	};
	
	public SampleBean(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "SampleBean [id=" + id + ", name=" + name + "]";
	};
	
	
	
	

}
