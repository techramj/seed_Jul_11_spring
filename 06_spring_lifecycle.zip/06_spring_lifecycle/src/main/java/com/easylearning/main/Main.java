package com.easylearning.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.easylearning.model.Bike;
import com.easylearning.model.Car;
import com.easylearning.model.SampleBean;

public class Main {
	
	public static void main(String[] args) {
		System.out.println("start");
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		//Bike bike = context.getBean("bike",Bike.class);
		//System.out.println(bike);
		Car car = context.getBean("car1", Car.class);
		
		SampleBean sb1 = context.getBean("sb1",SampleBean.class);
		SampleBean sb2 = context.getBean("sb2",SampleBean.class);
		
		System.out.println(sb1);
		System.out.println(sb2);
		
		
		
		((ConfigurableApplicationContext)context).close();
		
		
		
		
	}

}
