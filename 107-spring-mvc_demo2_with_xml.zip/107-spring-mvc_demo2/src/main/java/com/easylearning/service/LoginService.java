package com.easylearning.service;

import java.util.ArrayList;
import java.util.List;

public class LoginService {
	
	
	public boolean validate(String username, String password) {
		
		//some to validate
		return "123".equals(password);
	}
	
	public List<String> getFriendList(String user){
		//dao
		
		List<String> list= new ArrayList<String>();
		list.add("Jack");
		list.add("john");
		list.add("Harry");
		
		return list;
	}

}
