package com.easylearning.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HomeController {
	
	//http://localhost:8080/login
	@RequestMapping("/login")
	public String test(Model model) {
		
		model.addAttribute("name", "jack");
		model.addAttribute("password", "12345");
		
		System.out.println("test method called.......");
		return "homepage";
	}

}
