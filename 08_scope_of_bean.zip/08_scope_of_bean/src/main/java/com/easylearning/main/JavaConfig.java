package com.easylearning.main;

import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

import com.easylearning.model.Bike;


@Configuration
public class JavaConfig {

	
	@Lazy
	@Bean(initMethod = "init", destroyMethod = "destroy")
	public Bike bike() {
		return new Bike("Honda");
	}
	
	
}
