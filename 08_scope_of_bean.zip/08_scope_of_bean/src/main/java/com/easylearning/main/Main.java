package com.easylearning.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.easylearning.model.Bike;

public class Main {
	
	public static void main(String[] args) {
		ApplicationContext context= new AnnotationConfigApplicationContext(JavaConfig.class);
		//Bike b1 = context.getBean("bike", Bike.class);
		//Bike b2 = context.getBean("bike", Bike.class);
		
		
	}
	
	public static void sample2() {
		
		Thread t1= new Thread() {
			public void run() {
				for(int i=0;i<=5;i++) {
					Singleton ob1 = Singleton.getInstance();
					System.out.println(ob1);
				}
			}
		};
		
		Thread t2= new Thread() {
			public void run() {
				for(int i=0;i<=5;i++) {
					Singleton ob1 = Singleton.getInstance();
					System.out.println(ob1);
				}
			}
		};
		
		t1.start();
		t2.start();
		
	}
	
	public static void sample1() {
		System.out.println("start");
		ApplicationContext context = new AnnotationConfigApplicationContext(JavaConfig.class);
		Bike bike = context.getBean("bike",Bike.class);
		System.out.println(bike);
		((ConfigurableApplicationContext)context).close();
	}

}
