package com.easylearning;

/**
 * @author comp
 *
 */
public class User {

	private int userId;
	private String username;
	private String imagePath;
	private String nickName;

	public User() {
		// TODO Auto-generated constructor stub
	}

	public User(int userId, String username, String nickName) {
		super();
		this.userId = userId;
		this.username = username;
		this.nickName = nickName;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

}
